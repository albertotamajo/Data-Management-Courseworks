SELECT SUM(cases) AS totalCases,SUM(deaths) AS totalDeaths FROM CoronavirusCases;
