SELECT dateRep,cases FROM CoronavirusCases WHERE geoId="UK" ORDER BY dateRep;
